---
layout: post
title: SEO 常用资源
category: 资源
tags: SEO
keywords: SEO
---

## 小技巧

### URL中用`-`分割单词，用`_`关联单词

Google 会把 `a-good_reource-of-seo.html` 拆分成关键字：`a`, `good_resource`, `of` 和 `seo`。