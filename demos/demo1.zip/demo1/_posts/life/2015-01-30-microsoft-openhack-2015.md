---
layout: post
title: 微软 Openhack 2015
category: 生活
tags: Essay
keywords:
---

Hackathon 在国内也见过不少，不过一直没有参加过，一是熬夜实在是伤身体，二是以前不太好找队伍。这回室友喊我去参加，因为好奇这边IT的工作环境，就去参加了。

这次 Hackathon 的主题是 USC vs UCLA，这俩学校的 Football 一直是死敌，导致各方面也都开始竞争，在 [Wikipedia](http://en.wikipedia.org/wiki/UCLA–USC_rivalry) 上还有专门的词条来记录两校的竞争。

![USC vs UCLA](http://imgs.yansu.org/life-openhack-usc-vs-ucla.png)

上图是 Hackathon 一组队伍最终展示PPT时候的封面~

这次 Openhack 的奖品还好，第一是去西雅图总部玩，第二是人手一台XBOX.

![Prize](http://imgs.yansu.org/life-openhack-prize.png)

不过在中间每隔一个小时有一次小活动，奖品包含了XBOX和Surface Pro等 0_0 可惜活动都没法参加，对游戏规则都不明白。不过这边的工程师们还是挺逗的，唱歌跳舞神马的各种玩 High。

下图是洛杉矶微软办公室，这天里面基本上能坐的地方都被参加 Hackathon 的队伍挤满了。

![Office](http://imgs.yansu.org/life-openhack-microsoft-office.png)

我们的4个人的桌面~ 隔壁一哥带外星人来写代码，不过据说装了10个小时，Visual Studio 都没装完。

![table](http://imgs.yansu.org/life-openhack-table.png)
 最后是队伍合影 =_= 我是那个比较正常的

![team](http://imgs.yansu.org/life-openhack-team.png)
