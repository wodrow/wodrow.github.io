<template>
    <div class="login">
        login
        <div class="test">gasdfs</div>
    </div>
</template>

<script>
    export default {
        name: "Login"
    }
</script>

<style scoped>

</style>